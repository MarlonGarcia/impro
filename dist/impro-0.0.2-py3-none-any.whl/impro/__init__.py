# __init__.py

from .depth import *
from .monte_carlo import *
from .intelligence import *

# Version of the image-functions package
__version__ = "0.0.2"